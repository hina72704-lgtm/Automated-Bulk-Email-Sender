"""
Simple GUI Version using Tkinter
No complex stuff - just click buttons!
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog
from email_sender import BulkEmailSender
import threading

class EmailSenderGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Bulk Email Sender")
        self.root.geometry("700x600")
        self.root.configure(bg='#f0f0f0')
        
        self.sender = BulkEmailSender()
        
        # Create GUI elements
        self.create_widgets()
    
    def create_widgets(self):
        # Title
        title = tk.Label(self.root, text="📧 BULK EMAIL SENDER", 
                        font=("Arial", 18, "bold"), bg='#f0f0f0', fg='#333')
        title.pack(pady=10)
        
        # Frame for buttons
        button_frame = tk.Frame(self.root, bg='#f0f0f0')
        button_frame.pack(pady=10)
        
        # Buttons
        btn_style = {'font': ("Arial", 10), 'width': 20, 'height': 1}
        
        tk.Button(button_frame, text="📁 Load Contacts", command=self.load_contacts, **btn_style).grid(row=0, column=0, padx=5, pady=5)
        tk.Button(button_frame, text="📝 Load Template", command=self.load_template, **btn_style).grid(row=0, column=1, padx=5, pady=5)
        tk.Button(button_frame, text="🔧 Setup SMTP", command=self.setup_smtp, **btn_style).grid(row=1, column=0, padx=5, pady=5)
        tk.Button(button_frame, text="📤 Send Emails", command=self.send_emails, **btn_style).grid(row=1, column=1, padx=5, pady=5)
        tk.Button(button_frame, text="📜 View History", command=self.view_history, **btn_style).grid(row=2, column=0, padx=5, pady=5)
        tk.Button(button_frame, text="🔄 Create Samples", command=self.create_samples, **btn_style).grid(row=2, column=1, padx=5, pady=5)
        
        # Status display
        self.status_text = scrolledtext.ScrolledText(self.root, height=15, width=80, font=("Courier", 9))
        self.status_text.pack(pady=10, padx=10)
        
        # Progress bar
        self.progress = ttk.Progressbar(self.root, length=400, mode='indeterminate')
        self.progress.pack(pady=5)
        
        # Info label
        self.info_label = tk.Label(self.root, text="Ready!", bg='#f0f0f0', fg='#666')
        self.info_label.pack()
    
    def log(self, message):
        """Add message to status display"""
        self.status_text.insert(tk.END, message + "\n")
        self.status_text.see(tk.END)
        self.root.update()
    
    def load_contacts(self):
        filename = filedialog.askopenfilename(filetypes=[("CSV/JSON", "*.csv *.json")])
        if filename:
            if self.sender.load_contacts(filename):
                self.log(f"✅ Loaded {len(self.sender.contacts)} contacts")
            else:
                self.log("❌ Failed to load contacts")
    
    def load_template(self):
        filename = filedialog.askopenfilename(filetypes=[("Text files", "*.txt")])
        if filename:
            if self.sender.load_template(filename):
                self.log(f"✅ Template loaded: {filename}")
            else:
                self.log("❌ Failed to load template")
    
    def setup_smtp(self):
        # Simple dialog for email setup
        dialog = tk.Toplevel(self.root)
        dialog.title("SMTP Setup")
        dialog.geometry("400x250")
        
        tk.Label(dialog, text="Email:").pack(pady=5)
        email_entry = tk.Entry(dialog, width=40)
        email_entry.pack()
        
        tk.Label(dialog, text="Password/App Password:").pack(pady=5)
        pass_entry = tk.Entry(dialog, width=40, show="*")
        pass_entry.pack()
        
        tk.Label(dialog, text="Provider:").pack(pady=5)
        provider = ttk.Combobox(dialog, values=["Gmail", "Outlook", "Yahoo"], width=37)
        provider.pack()
        provider.set("Gmail")
        
        def save_smtp():
            self.sender.sender_email = email_entry.get()
            self.sender.sender_password = pass_entry.get()
            
            provider_map = {
                "Gmail": ("smtp.gmail.com", 587),
                "Outlook": ("smtp-mail.outlook.com", 587),
                "Yahoo": ("smtp.mail.yahoo.com", 587)
            }
            self.sender.smtp_server, self.sender.smtp_port = provider_map[provider.get()]
            
            self.log(f"✅ SMTP configured for {self.sender.sender_email}")
            dialog.destroy()
        
        tk.Button(dialog, text="Save", command=save_smtp, bg='green', fg='white').pack(pady=10)
    
    def send_emails(self):
        if not self.sender.contacts:
            self.log("❌ No contacts loaded!")
            return
        if 'current' not in self.sender.templates:
            self.log("❌ No template loaded!")
            return
        if not self.sender.sender_email:
            self.log("❌ SMTP not configured!")
            return
        
        # Run in separate thread to not freeze GUI
        def send_thread():
            self.progress.start()
            self.log("\n" + "="*40)
            self.log("📤 Sending emails...")
            self.sender.send_bulk_emails()
            self.log("✅ Sending complete!")
            self.progress.stop()
            self.info_label.config(text="Send complete!")
        
        threading.Thread(target=send_thread, daemon=True).start()
        self.info_label.config(text="Sending emails...")
    
    def view_history(self):
        self.sender.view_history()
        # Also show in log
        self.log("\n📜 Email History:")
        for record in self.sender.history[-10:]:
            status = "✅" if "Sent" in record['status'] else "❌"
            self.log(f"{status} {record['timestamp']} - {record['email']} - {record['status'][:30]}")
    
    def create_samples(self):
        self.sender.create_sample_contacts()
        self.sender.create_sample_template()
        self.log("✅ Created sample_contacts.csv and sample_template.txt")


def run_gui():
    root = tk.Tk()
    app = EmailSenderGUI(root)
    root.mainloop()

if __name__ == "__main__":
    run_gui()









    