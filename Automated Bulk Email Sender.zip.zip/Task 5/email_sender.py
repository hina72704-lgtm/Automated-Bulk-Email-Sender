#!/usr/bin/env python3
"""
Automated Bulk Email Sender with Templates
A Python tool to send personalized bulk emails using templates
"""

import smtplib
import csv
import json
import os
from datetime import datetime
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
import time
import re

class BulkEmailSender:
    """Main class for sending bulk emails with templates"""
    
    def __init__(self):
        self.contacts = []  # List of contact dictionaries
        self.templates = {}  # Dictionary of templates
        self.history = []  # List of sent email records
        self.smtp_server = None
        self.smtp_port = None
        self.sender_email = None
        self.sender_password = None
        
        # Load existing history if available
        self.load_history()
    
    def load_contacts(self, filename):
        """Load contacts from CSV or JSON file"""
        try:
            if not os.path.exists(filename):
                raise FileNotFoundError(f"File not found: {filename}")
            
            if filename.endswith('.csv'):
                with open(filename, 'r', encoding='utf-8') as file:
                    reader = csv.DictReader(file)
                    self.contacts = list(reader)
            elif filename.endswith('.json'):
                with open(filename, 'r', encoding='utf-8') as file:
                    self.contacts = json.load(file)
            else:
                raise ValueError("Only CSV or JSON files are supported")
            
            print(f"✅ Loaded {len(self.contacts)} contacts from {filename}")
            return True
            
        except Exception as e:
            print(f"❌ Error loading contacts: {e}")
            return False
    
    def create_sample_contacts(self):
        """Create a sample contacts file for testing"""
        sample_data = [
            {"name": "Ali Khan", "email": "alikhan@example.com", "company": "Tech Solutions"},
            {"name": "Sara Ahmed", "email": "sara.ahmed@example.com", "company": "Digital Media"},
            {"name": "Ahmed Raza", "email": "ahmed.r@example.com", "company": "Creative Agency"},
            {"name": "Fatima Ali", "email": "fatima.ali@example.com", "company": "Startup Hub"},
            {"name": "Omar Farooq", "email": "omar.f@example.com", "company": "Business Group"}
        ]
        
        # Save as CSV
        with open('sample_contacts.csv', 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=["name", "email", "company"])
            writer.writeheader()
            writer.writerows(sample_data)
        
        # Save as JSON
        with open('sample_contacts.json', 'w', encoding='utf-8') as f:
            json.dump(sample_data, f, indent=2)
        
        print("✅ Created sample_contacts.csv and sample_contacts.json")
        return "sample_contacts.csv"
    
    def load_template(self, filename):
        """Load email template from file"""
        try:
            if not os.path.exists(filename):
                raise FileNotFoundError(f"Template file not found: {filename}")
            
            with open(filename, 'r', encoding='utf-8') as file:
                content = file.read()
            
            # Parse template (first line can be subject)
            lines = content.strip().split('\n')
            subject = lines[0].replace('Subject:', '').strip() if lines[0].startswith('Subject:') else "Hello {name}"
            body = '\n'.join(lines[1:]) if lines[0].startswith('Subject:') else content
            
            self.templates['current'] = {
                'subject': subject,
                'body': body
            }
            
            print(f"✅ Template loaded: {filename}")
            print(f"   Subject: {subject}")
            return True
            
        except Exception as e:
            print(f"❌ Error loading template: {e}")
            return False
    
    def create_sample_template(self):
        """Create a sample template file"""
        template_content = """Subject: Welcome to Our Platform!

Dear,

We are excited to welcome you from {company} to our platform!

This is a personalized email just for you. We hope you enjoy our services.

Best regards,
The Team

P.S. Check out our latest features!"""
        
        with open('sample_template.txt', 'w', encoding='utf-8') as f:
            f.write(template_content)
        
        print("✅ Created sample_template.txt")
        return "sample_template.txt"
    
    def personalize_email(self, template, contact):
        """Replace placeholders with actual contact data"""
        subject = template['subject']
        body = template['body']
        
        # Replace all placeholders like {name}, {company}
        for key, value in contact.items():
            placeholder = '{' + key + '}'
            subject = subject.replace(placeholder, str(value))
            body = body.replace(placeholder, str(value))
        
        return subject, body
    
    def setup_smtp(self):
        """Setup SMTP connection with user credentials"""
        print("\n📧 SMTP Configuration")
        print("-" * 40)
        print("For Gmail: Use App Password (not regular password)")
        print("Get app password: Google Account → Security → App Passwords")
        print("-" * 40)
        
        self.sender_email = input("Enter your email: ").strip()
        self.sender_password = input("Enter your password/app password: ").strip()
        
        print("\nSelect Email Provider:")
        print("1. Gmail")
        print("2. Outlook/Hotmail")
        print("3. Yahoo")
        print("4. Custom SMTP")
        
        choice = input("Choose (1-4): ").strip()
        
        if choice == '1':
            self.smtp_server = "smtp.gmail.com"
            self.smtp_port = 587
        elif choice == '2':
            self.smtp_server = "smtp-mail.outlook.com"
            self.smtp_port = 587
        elif choice == '3':
            self.smtp_server = "smtp.mail.yahoo.com"
            self.smtp_port = 587
        elif choice == '4':
            self.smtp_server = input("SMTP Server: ").strip()
            self.smtp_port = int(input("SMTP Port: ").strip())
        else:
            print("❌ Invalid choice, using Gmail as default")
            self.smtp_server = "smtp.gmail.com"
            self.smtp_port = 587
        
        return True
    
    def send_single_email(self, to_email, subject, body, retry=2):
        """Send a single email with retry mechanism"""
        for attempt in range(retry):
            try:
                # Create message
                msg = MIMEMultipart()
                msg['From'] = self.sender_email
                msg['To'] = to_email
                msg['Subject'] = subject
                msg.attach(MIMEText(body, 'plain'))
                
                # Connect and send
                with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                    server.starttls()
                    server.login(self.sender_email, self.sender_password)
                    server.send_message(msg)
                
                return True, "Sent successfully"
                
            except smtplib.SMTPAuthenticationError:
                return False, "Authentication failed - Check email/password"
            except smtplib.SMTPRecipientsRefused:
                return False, "Invalid recipient email"
            except Exception as e:
                if attempt < retry - 1:
                    print(f"   Retry {attempt + 1}/{retry} for {to_email}...")
                    time.sleep(2)
                else:
                    return False, f"Failed: {str(e)[:50]}"
        
        return False, "Max retries exceeded"
    
    def send_bulk_emails(self):
        """Send emails to all loaded contacts"""
        if not self.contacts:
            print("❌ No contacts loaded. Please load contacts first.")
            return False
        
        if 'current' not in self.templates:
            print("❌ No template loaded. Please load a template first.")
            return False
        
        if not self.sender_email:
            self.setup_smtp()
        
        print(f"\n📤 Sending {len(self.contacts)} emails...")
        print("-" * 40)
        
        success_count = 0
        fail_count = 0
        
        for i, contact in enumerate(self.contacts, 1):
            # Validate email
            email = contact.get('email', '')
            if not self.is_valid_email(email):
                print(f"{i}. ❌ Invalid email: {email}")
                self.save_to_history(email, "Invalid email format", "Failed")
                fail_count += 1
                continue
            
            # Personalize email
            subject, body = self.personalize_email(self.templates['current'], contact)
            
            # Send email
            print(f"{i}. Sending to {contact.get('name', 'Unknown')} ({email})...", end=" ")
            success, message = self.send_single_email(email, subject, body)
            
            if success:
                print("✅ Success")
                success_count += 1
                self.save_to_history(email, subject, "Sent")
            else:
                print(f"❌ {message}")
                fail_count += 1
                self.save_to_history(email, subject, f"Failed: {message}")
            
            # Small delay to avoid rate limiting
            time.sleep(1)
        
        print("\n" + "=" * 40)
        print(f"📊 Summary: {success_count} Sent, {fail_count} Failed")
        print("=" * 40)
        
        return success_count > 0
    
    def is_valid_email(self, email):
        """Validate email format"""
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return re.match(pattern, email) is not None
    
    def save_to_history(self, email, subject, status):
        """Save email record to history"""
        record = {
            'email': email,
            'subject': subject,
            'status': status,
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        self.history.append(record)
        self.save_history()
    
    def save_history(self):
        """Save history to JSON file"""
        try:
            with open('email_history.json', 'w', encoding='utf-8') as f:
                json.dump(self.history, f, indent=2)
        except Exception as e:
            print(f"Warning: Could not save history - {e}")
    
    def load_history(self):
        """Load history from JSON file"""
        try:
            if os.path.exists('email_history.json'):
                with open('email_history.json', 'r', encoding='utf-8') as f:
                    self.history = json.load(f)
                print(f"📜 Loaded {len(self.history)} history records")
        except Exception:
            self.history = []
    
    def view_history(self):
        """Display email history"""
        if not self.history:
            print("\n📜 No email history found.")
            return
        
        print("\n" + "=" * 70)
        print("📜 EMAIL HISTORY")
        print("=" * 70)
        
        for i, record in enumerate(self.history[-20:], 1):  # Show last 20
            status_symbol = "✅" if "Sent" in record['status'] else "❌"
            print(f"{i}. {status_symbol} {record['timestamp']}")
            print(f"   To: {record['email']}")
            print(f"   Subject: {record['subject'][:50]}")
            print(f"   Status: {record['status']}")
            print("-" * 70)


def interactive_menu():
    """Interactive CLI menu"""
    sender = BulkEmailSender()
    
    while True:
        print("\n" + "=" * 50)
        print("   📧 BULK EMAIL SENDER SYSTEM")
        print("=" * 50)
        print("1. Load Contacts (CSV/JSON)")
        print("2. Create Sample Contacts File")
        print("3. Load Email Template")
        print("4. Create Sample Template")
        print("5. Setup SMTP & Send Emails")
        print("6. View Email History")
        print("7. Exit")
        print("-" * 50)
        
        choice = input("Enter your choice (1-7): ").strip()
        
        if choice == '1':
            filename = input("Enter contacts filename (CSV/JSON): ").strip()
            sender.load_contacts(filename)
        
        elif choice == '2':
            sender.create_sample_contacts()
            print("\n📁 Created sample files! Use 'sample_contacts.csv' for testing.")
        
        elif choice == '3':
            filename = input("Enter template filename: ").strip()
            sender.load_template(filename)
        
        elif choice == '4':
            sender.create_sample_template()
            print("\n📁 Created sample_template.txt! Edit it to customize.")
        
        elif choice == '5':
            if not sender.contacts:
                print("⚠️ No contacts loaded. Load or create contacts first.")
                continue
            if 'current' not in sender.templates:
                print("⚠️ No template loaded. Load or create a template first.")
                continue
            
            sender.setup_smtp()
            confirm = input("\n⚠️ Ready to send emails? (yes/no): ").strip().lower()
            if confirm == 'yes':
                sender.send_bulk_emails()
            else:
                print("Send cancelled.")
        
        elif choice == '6':
            sender.view_history()
        
        elif choice == '7':
            print("\n👋 Goodbye! Thanks for using Email Sender!")
            break
        
        else:
            print("❌ Invalid choice. Please enter 1-7.")


def main():
    """Entry point"""
    print("🔧 Automated Bulk Email Sender 🔧")
    print("Version 1.0 | Developed for Email Marketing")
    print("\n⚠️ IMPORTANT:")
    print("   - For Gmail, use App Password (not regular password)")
    print("   - Get it: Google Account → Security → App Passwords")
    print("   - Test with your own email first!")
    
    interactive_menu()


if __name__ == "__main__":
    main()